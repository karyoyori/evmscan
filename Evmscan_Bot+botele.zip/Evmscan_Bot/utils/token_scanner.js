const ERC20_ABI = require('../abi/erc20.json');
const { getChains, getWeb3 } = require('./network_utils');

async function scanTokens(address) {
  const tokens = [];

  for (const chain of getChains()) {
    const web3 = getWeb3(chain);

    try {
      const balance = await web3.eth.getBalance(address);
      const ethBalance = web3.utils.fromWei(balance, 'ether');
      tokens.push({ chain, token: 'Native', balance: ethBalance });
    } catch (error) {
      console.error(`Gagal scan ${chain}: ${error.message}`);
    }
  }

  return tokens;
}

async function detectTokenName(contractAddress) {
  for (const chain of getChains()) {
    const web3 = getWeb3(chain);

    try {
      const contract = new web3.eth.Contract(ERC20_ABI, contractAddress);
      const name = await contract.methods.name().call();
      return { chain, name };
    } catch (error) {
      continue;
    }
  }

  return null;
}

module.exports = { scanTokens, detectTokenName };
