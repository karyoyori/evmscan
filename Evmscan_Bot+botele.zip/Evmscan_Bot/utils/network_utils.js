const Web3 = require('web3');
const config = require('../config.json');

const web3Instances = {};

for (const [chain, rpcUrl] of Object.entries(config.rpcs)) {
  web3Instances[chain] = new Web3(rpcUrl);
}

function getChains() {
  return Object.keys(web3Instances);
}

function getWeb3(chainName) {
  return web3Instances[chainName];
}

module.exports = { getChains, getWeb3 };
