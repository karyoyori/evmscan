const axios = require('axios');
const config = require('../config.json');

async function getEthGasPrice() {
  try {
    const res = await axios.get(config.gas_api);
    return {
      fast: res.data.fast / 10,
      average: res.data.average / 10,
      safeLow: res.data.safeLow / 10
    };
  } catch (error) {
    console.error('Gagal ambil data gas:', error.message);
    return null;
  }
}

module.exports = { getEthGasPrice };
