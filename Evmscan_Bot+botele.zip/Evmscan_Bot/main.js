const TelegramBot = require('node-telegram-bot-api');
const { scanTokens, detectTokenName } = require('./utils/token_scanner');
const { getEthGasPrice } = require('./utils/gas_checker');
const config = require('./config.json');
const Web3 = require('web3');

const bot = new TelegramBot(config.telegram_token, { polling: true });

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, "Selamat datang!\n\nPerintah:\n/scan_address alamat\n/scan_private privatekey\n/token contract_address\n/gas");
});

bot.onText(/\/scan_address (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const address = match[1].trim();

  bot.sendMessage(chatId, `Scanning alamat: ${address}...`);

  const tokens = await scanTokens(address);

  let result = `Hasil Scan untuk ${address}:\n`;
  tokens.forEach(token => {
    result += `\n• Jaringan: ${token.chain.toUpperCase()}\n• Token: ${token.token}\n• Saldo: ${token.balance}\n`;
  });

  bot.sendMessage(chatId, result);
});

bot.onText(/\/scan_private (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const privateKey = match[1].trim();

  try {
    const account = new Web3().eth.accounts.privateKeyToAccount(privateKey);
    const address = account.address;

    bot.sendMessage(chatId, `Private key valid.\nAlamat: ${address}\nMulai scan...`);

    const tokens = await scanTokens(address);

    let result = `Hasil Scan untuk ${address}:\n`;
    tokens.forEach(token => {
      result += `\n• Jaringan: ${token.chain.toUpperCase()}\n• Token: ${token.token}\n• Saldo: ${token.balance}\n`;
    });

    bot.sendMessage(chatId, result);

  } catch (error) {
    bot.sendMessage(chatId, "Private key tidak valid.");
  }
});

bot.onText(/\/token (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const contractAddress = match[1].trim();

  bot.sendMessage(chatId, `Mendeteksi token dari kontrak: ${contractAddress}...`);

  const result = await detectTokenName(contractAddress);

  if (result) {
    bot.sendMessage(chatId, `Token terdeteksi:\n\n• Nama: ${result.name}\n• Jaringan: ${result.chain.toUpperCase()}`);
  } else {
    bot.sendMessage(chatId, "Token tidak ditemukan atau kontrak tidak valid.");
  }
});

bot.onText(/\/gas/, async (msg) => {
  const chatId = msg.chat.id;
  const gas = await getEthGasPrice();

  if (gas) {
    bot.sendMessage(chatId, `Harga Gas ETH sekarang:\n\n• Cepat: ${gas.fast} Gwei\n• Normal: ${gas.average} Gwei\n• Murah: ${gas.safeLow} Gwei`);
  } else {
    bot.sendMessage(chatId, "Gagal mengambil data harga gas.");
  }
});
