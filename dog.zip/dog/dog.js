import axios from 'axios'
import { HttpsProxyAgent } from 'https-proxy-agent'
import { promises as fs } from 'fs' // Use fs.promises
import fsSync from 'fs' // Use synchronous fs for request interception checks
import path from 'path'
import { fileURLToPath } from 'url'
// Correctly import 'connect'
import { connect } from "puppeteer-real-browser"

// Assuming './recaptcha.js' exists and exports a working RecaptchaSolver class
import RecaptchaSolver from './recaptcha.js'

// --- Constants ---
const DOGENANO_RPC_URL = "https://rpc.dogenano.io/proxy"
const NANSWAP_FAUCET_URL = "https://api.nanswap.com/get-free"
const RECAPTCHA_ANCHOR_URL = "https://www.google.com/recaptcha/api2/anchor?ar=1&k=6LcqYeMeAAAAAHxf1texnOx4Kpz_bX79yorcs3-f&co=aHR0cHM6Ly9uYW5zd2FwLmNvbTo0NDM.&hl=en&type=image&v=ItfkQiGBlJDHuTkOhlT3zHpB&theme=light&size=invisible&badge=bottomleft&cb=hwxkvh1skkzf"
const AXIOS_PROXY_URL = "http://user:pw@ip:port" // Or your Axios proxy
const WALLET_PASSWORD = "thispassword"
const DEFAULT_TIMEOUT = 60000

const FAUCET_WAIT_TIMEOUT = 180000 // 3 minutes
const OUTPUT_FILE = 'doge.json'
const MAX_CONCURRENT_WORKERS = 5
const LOCAL_JS_FILENAME = 'main-es2015.d3206d74eddf61074725.js' // Ensure this file exists locally
const REMOTE_JS_URL = `https://wallet.dogenano.io/${LOCAL_JS_FILENAME}`

// Conversion Factor: 1 XDG = 10^26 raw
const RAW_PER_XDG_EXPONENT = 26
const DIVISOR_BIGINT = 10n ** BigInt(RAW_PER_XDG_EXPONENT) // 10^26 as BigInt

const BLOCKED_STATIC_URLS = [
    'https://wallet.dogenano.io/assets/lib/base/uikit-icons.min.js',
    'https://wallet.dogenano.io/assets/img/dogenano.png',
    'https://wallet.dogenano.io/assets/lib/base/uikit.min.js',
    'https://fonts.gstatic.com/',
    'https://wallet.dogenano.io/nano-mark.974cac05f8829859b2f4.svg',
]
const proxyList = [
    AXIOS_PROXY_URL,

]

// Select proxy details
const randomProxyString = proxyList[Math.floor(Math.random() * proxyList.length)]
const [auth, hostPort] = randomProxyString.split('@')
const [username, password] = auth.split(':')
const puppeteerProxyHost = hostPort // e.g. gw.dataimpulse.com:10000
// Combine host and port for the argument string
const puppeteerProxyArg = `${puppeteerProxyHost}` // e.g., "gw.dataimpulse.com:10000"


const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const localJsPath = path.join(__dirname, LOCAL_JS_FILENAME) // Define localJsPath globally

// --- Axios Setup ---
const proxyAgent = AXIOS_PROXY_URL ? new HttpsProxyAgent(AXIOS_PROXY_URL) : undefined
const apiClient = axios.create({
    httpsAgent: proxyAgent,
    timeout: DEFAULT_TIMEOUT,
    headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36',
        'Content-Type': 'application/json'
    }
})

// --- Logging ---
const logAxiosError = (context, error) => {
    const details = axios.isAxiosError(error)
        ? `Msg: ${error.message}, Status: ${error.response?.status}, Data: ${JSON.stringify(error.response?.data)}`
        : `Error: ${error}`
    console.error(`[${context}] Failure - ${details}`)
}

// --- Helpers ---
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms))

// --- File Saving (Only saves successful detections) ---
const OUTPUT_FILE_PATH = path.join(__dirname, OUTPUT_FILE)
async function saveWalletData(walletInfo) {
    console.log(`[File] Attempting to save wallet: ${walletInfo.account.substring(0, 12)}...`)
    let wallets = []
    try {
        const existingData = await fs.readFile(OUTPUT_FILE_PATH, { encoding: 'utf-8' })
        wallets = JSON.parse(existingData)
        if (!Array.isArray(wallets)) wallets = []
    } catch (readError) {
        if (readError.code === 'ENOENT') console.log(`[File] ${OUTPUT_FILE} not found. Creating new file.`)
        else if (readError instanceof SyntaxError) console.warn(`[File] Error parsing ${OUTPUT_FILE}. Overwriting.`)
        else console.error(`[File] Error reading ${OUTPUT_FILE}: ${readError.message}`)
        wallets = []
    }

    try {
        if (!wallets.some(w => w.account === walletInfo.account)) {
            // Ensure amount is valid and non-zero before saving
            if (walletInfo.amount && walletInfo.amount !== "0.0") {
                wallets.push({
                    account: walletInfo.account,
                    private: walletInfo.private,
                    public: walletInfo.public,
                    amount: String(walletInfo.amount)
                })
                await fs.writeFile(OUTPUT_FILE_PATH, JSON.stringify(wallets, null, 2), 'utf-8')
                console.log(`✅ [File] Saved ${walletInfo.account.substring(0, 12)}... (Amount: ${walletInfo.amount}) to ${OUTPUT_FILE}`)
            } else {
                console.log(`[File] Skipping save for ${walletInfo.account.substring(0, 12)}... (Amount is zero or missing).`)
            }
        } else {
            console.log(`[File] Wallet ${walletInfo.account.substring(0, 12)}... already exists. Skipping save.`)
        }
    } catch (writeError) {
        console.error(`❌ [File] Error writing wallet data for ${walletInfo.account.substring(0, 12)}...: ${writeError.message}`)
    }
}

// --- Core Logic Functions ---
async function makeRpcRequest(action, params = {}, options = {}, retries = 3, retryDelay = 2000) {
    for (let i = 0;i < retries;i++) {
        try {
            const payload = { action, ...params }
            const response = await apiClient.post(DOGENANO_RPC_URL, payload, { timeout: options.timeout || DEFAULT_TIMEOUT })
            if (response.status === 200 && response.data) return response.data
            console.warn(`[RPC ${action}] Attempt ${i + 1}/${retries}: Received status ${response.status}`)
        } catch (error) {
            logAxiosError(`RPC ${action} (Attempt ${i + 1}/${retries})`, error)
            if (i === retries - 1) { console.error(`[RPC ${action}] Max retries reached.`); return null }
            const isRetryable = axios.isAxiosError(error) && (error.code === 'ECONNRESET' || error.code === 'ETIMEDOUT' || error.code === 'ECONNABORTED' || error.response?.status >= 500)
            if (isRetryable) { const delay = retryDelay * (i + 1); console.warn(`[RPC ${action}] Retrying in ${delay / 1000}s...`); await sleep(delay) }
            else { console.error(`[RPC ${action}] Non-retryable error.`); return null }
        }
    }
    return null
}
async function generateWallet() {
    const keyData = await makeRpcRequest("key_create")
    if (keyData?.account && keyData?.private && keyData?.public) { console.log(`[Wallet] Generated: ${keyData.account.substring(0, 12)}...`); return { account: keyData.account, private: keyData.private, public: keyData.public } }
    else { console.error(`[Wallet] Key creation failed.`); return null }
}
async function getRecaptchaToken() {
    try { console.log("[Captcha] Initializing solver..."); const solver = new RecaptchaSolver({ url: RECAPTCHA_ANCHOR_URL }); console.log("[Captcha] Attempting to get token..."); const token = await solver._get_token(); if (token) { console.log("[Captcha] Token obtained."); return token } console.error("[Captcha] Failed: Solver returned null/empty token."); return null }
    catch (error) { console.error(`[Captcha] Error obtaining token: ${error.message}\n${error.stack}`); return null }
}
async function requestFaucet(address, challengeToken) {
    const payload = { address, challenge: challengeToken, ticker: "XDG" }
    try { const response = await apiClient.post(NANSWAP_FAUCET_URL, payload); if (response.status === 200 && response.data?.hash && response.data?.amountSent) { console.log(`[Faucet] Request successful for ${address.substring(0, 12)}... Hash: ${response.data.hash.substring(0, 8)}...`); return response.data.amountSent } else { const errorMsg = response.data?.error || JSON.stringify(response.data); console.warn(`[Faucet] Request Warning/Error for ${address.substring(0, 12)}... Status: ${response.status}, Body: ${errorMsg}`); return null } }
    catch (error) { logAxiosError(`Faucet Request for ${address.substring(0, 12)}...`, error); return null }
}

// --- Puppeteer Function ---
async function detectBalanceAndSave(walletInfo) {
    const { account: walletAddress, private: privateKey } = walletInfo
    console.log(`[Browser ${walletAddress.substring(0, 12)}] Launching...`)
    let browser = null
    let page = null
    let balanceDetectedAndSaved = false
    const startTime = Date.now()
    let networkListenerActive = true

    if (!fsSync.existsSync(localJsPath)) {
        console.error(`❌ [Browser ${walletAddress.substring(0, 12)}] Critical Error: Local JS file not found at ${localJsPath}. Aborting browser task.`)
        return false
    }

    try {
        console.log(`[Browser ${walletAddress.substring(0, 12)}] Connecting with proxy: ${puppeteerProxyArg}`)

        const { browser: connectedBrowser } = await connect({
            headless: true, // <-- Keep false until selector is confirmed working
            turnstile: true,
            ignoreHTTPSErrors: true,
            connectOption: {
                args: [
                    `--proxy-server=http://${puppeteerProxyArg}`,
                    `--ignore-certificate-errors`,
                    `--allow-insecure-localhost`,
                    `--disable-web-security`,
                    `--ignore-certificate-errors-spki-list`,
                    `--allow-running-insecure-content`,
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-dev-shm-usage',
                    '--disable-extensions',
                    '--disable-component-extensions-with-background-pages',
                    '--disable-default-apps',
                    '--no-default-browser-check',
                    '--disable-sync',
                    '--disable-background-networking',
                    '--disable-background-timer-throttling',
                    '--disable-backgrounding-occluded-windows',
                    '--disable-renderer-backgrounding',
                    '--disable-features=site-per-process,TranslateUI',
                    '--disable-hang-monitor',
                    '--disable-ipc-flooding-protection',
                    '--disable-popup-blocking',
                    '--disable-prompt-on-repost',
                    '--disable-breakpad',
                    '--disable-client-side-phishing-detection',
                    '--disable-features=CalculateNativeWinOcclusion',
                    '--disable-features=InterestFeedV2',
                    '--disable-features=GlobalMediaControls',
                    '--disable-features=DestroyProfileOnBrowserClose'
                ],
                ignoreHTTPSErrors: true,
            },
            disableXvfb: false,
        })
        browser = connectedBrowser

        if (!browser) throw new Error("Connect function did not return a browser object.")
        console.log(`[Browser ${walletAddress.substring(0, 12)}] Browser object obtained.`)

        page = await browser.newPage()
        console.log(`[Browser ${walletAddress.substring(0, 12)}] Page created.`)

        console.log(`[Browser ${walletAddress.substring(0, 12)}] Authenticating proxy user: ${username}`)
        await page.authenticate({ username, password })
        await page.setDefaultNavigationTimeout(90000)
        await page.setRequestInterception(true)

        // --- Network Interception ---
        page.on('request', (request) => {
            if (!page || page.isClosed()) { if (!request.isInterceptResolutionHandled()) request.abort('failed').catch(e => { }); return }
            const url = request.url(); const resourceType = request.resourceType(); if (request.isInterceptResolutionHandled()) return
            if (url === REMOTE_JS_URL) { try { const body = fsSync.readFileSync(localJsPath, 'utf8'); request.respond({ status: 200, contentType: 'application/javascript; charset=utf-8', body }).catch(e => { }) } catch (e) { request.abort('failed').catch(e => { }) } }
            else if (BLOCKED_STATIC_URLS.some(blocked => url.startsWith(blocked)) || ['image', 'font', 'media', 'stylesheet'].includes(resourceType)) { request.abort().catch(e => { }) }
            else { request.continue().catch(e => { }) }
        })

        // --- Network Monitoring ---
        page.on('response', async (response) => {
            if (!page || page.isClosed()) return

            const url = response.url()
            if (url !== DOGENANO_RPC_URL) return

            const status = response.status()
            const method = response.request().method()

            if (method !== 'POST') return


            try {
                const requestText = response.request().postData()

                let requestPayload = null
                try {
                    requestPayload = JSON.parse(requestText)
                } catch (e) {
                    console.warn(`[Browser ${walletAddress.substring(0, 12)}] ⚠️ Failed to parse postData as JSON`)
                    return
                }


                const responseData = await response.json().catch(() => null)

                if (
                    requestPayload &&
                    requestPayload.action === 'account_info' &&
                    requestPayload.account === walletAddress &&
                    responseData &&
                    responseData.balance !== undefined
                ) {
                    const rawBalance = BigInt(responseData.balance)

                    if (rawBalance > 0n) {
                        balanceDetectedAndSaved = true
                        networkListenerActive = false

                        const integerPart = rawBalance / DIVISOR_BIGINT
                        const remainder = rawBalance % DIVISOR_BIGINT
                        let fractionalPart = String(remainder).padStart(RAW_PER_XDG_EXPONENT, '0').replace(/0+$/, '')
                        if (fractionalPart === '') fractionalPart = '0'

                        const decimalAmountString = `${integerPart}.${fractionalPart}`
                        console.log(`✅ [Browser ${walletAddress.substring(0, 12)}] Raw Balance ${rawBalance} DETECTED. Converted to ${decimalAmountString} XDG.`)

                        await saveWalletData({ ...walletInfo, amount: decimalAmountString })

                        console.log(`[Browser ${walletAddress.substring(0, 12)}] Closing browser after saving balance.`)
                        if (browser) await browser.close().catch(e => console.warn(`Error closing browser (listener): ${e.message}`))
                        browser = null
                        page = null
                    }
                }

            } catch (err) {
                console.warn(`[Browser ${walletAddress.substring(0, 12)}] ⚠️ Error in network listener: ${err.message}`)
            }
        })


        // --- End Network Monitoring ---

        console.log(`[Browser ${walletAddress.substring(0, 12)}] Navigating to wallet page...`)
        await page.goto('https://wallet.dogenano.io/configure-wallet?import=1', { timeout: 60000 })

        // --- Wallet Import Steps ---
        console.log(`[Browser ${walletAddress.substring(0, 12)}] Importing wallet...`)
        try {


            // Step 1: Find and Click "More Options" button
            const moreOptionsButtonSelector = 'button.wallet-option.more-options'
            try {
                console.log(`[Browser ${walletAddress.substring(0, 12)}] Waiting for 'More Options' button: ${moreOptionsButtonSelector}`)
                await page.waitForSelector(moreOptionsButtonSelector, { visible: true, timeout: 15000 })
                console.log(`[Browser ${walletAddress.substring(0, 12)}] Found 'More Options' button. Clicking...`)
                await page.click(moreOptionsButtonSelector)
                console.log(`[Browser ${walletAddress.substring(0, 12)}] Clicked 'More Options'.`)
            } catch (e) {
                console.error(`❌ [Browser ${walletAddress.substring(0, 12)}] CRITICAL: Could not find the 'More Options' button with selector '${moreOptionsButtonSelector}'. Error: ${e.message}`)
                throw new Error(`'More Options' button not found.`)
            }

            // After clicking "More Options", wait for DOM changes/animation
            console.log(`[Browser ${walletAddress.substring(0, 12)}] Waiting for animation to complete...`)
            await sleep(3000) // Longer wait to ensure animation completes

            // Go with the simplest approach - click the button by its index
            console.log(`[Browser ${walletAddress.substring(0, 12)}] Looking for 'Import Private Key' button...`)

            try {
                // Based on the debug output, we know it's button index 5
                const result = await page.evaluate(() => {
                    const buttons = document.querySelectorAll('button.wallet-option')
                    if (buttons.length >= 6) {
                        // Button at index 5 is the "Import Private Key" button
                        buttons[5].click()
                        return true
                    }
                    return false
                })

                if (result) {
                    console.log(`[Browser ${walletAddress.substring(0, 12)}] Successfully clicked button at index 5.`)
                } else {
                    throw new Error("Button at index 5 not found")
                }
            } catch (e) {
                console.error(`❌ [Browser ${walletAddress.substring(0, 12)}] Failed to click button at index 5: ${e.message}`)

                // Try an even simpler approach using the textContent
                console.log(`[Browser ${walletAddress.substring(0, 12)}] Trying alternative approach with textContent...`)

                try {
                    const clicked = await page.evaluate(() => {
                        const buttons = Array.from(document.querySelectorAll('button.wallet-option'))
                        for (const button of buttons) {
                            // Simple string matching approach
                            if (button.textContent.includes('Import Private Key') &&
                                !button.textContent.includes('Expanded')) {
                                button.click()
                                return true
                            }
                        }
                        return false
                    })

                    if (clicked) {
                        console.log(`[Browser ${walletAddress.substring(0, 12)}] Successfully clicked button using textContent match.`)
                    } else {
                        throw new Error("Button with matching text not found")
                    }
                } catch (textErr) {
                    console.error(`❌ [Browser ${walletAddress.substring(0, 12)}] Text matching approach failed: ${textErr.message}`)
                    throw new Error('All attempts to find and click the Import Private Key button failed')
                }
            }
            const privateKeyInputSelector = 'input.uk-input[placeholder*="Private Key"]'
            console.log(`[Browser ${walletAddress.substring(0, 12)}] Waiting for private key input field...`)
            await page.waitForSelector(privateKeyInputSelector, { visible: true, timeout: 10000 })

            await page.evaluate((selector, value) => {
                const input = document.querySelector(selector)
                input.focus()
                input.value = value
                input.dispatchEvent(new Event('input', { bubbles: true }))
            }, privateKeyInputSelector, privateKey)

            console.log(`[Browser ${walletAddress.substring(0, 12)}] Pasted private key.`)
            await page.evaluate(() => {
                const buttons = Array.from(document.querySelectorAll('button'))

                const btn = buttons.find(b => b.textContent.trim() === 'Import From Private Key')
                if (btn) {
                    btn.scrollIntoView({ behavior: 'smooth', block: 'center' })
                    btn.click()
                    btn.dispatchEvent(new MouseEvent('click', { bubbles: true }))
                }
            })
            await sleep(1000) // Wait after submitting key

            // Step 4: Enter Password
            // Step 4: Enter Password and Click "Import Wallet"
            const newPasswordSelector = 'input[placeholder="New Wallet Password"]'
            const confirmPasswordSelector = 'input[placeholder="Confirm Wallet Password"]'

            console.log(`[Browser ${walletAddress.substring(0, 12)}] Waiting for password input fields...`)
            await page.waitForSelector(newPasswordSelector, { visible: true, timeout: 15000 })

            await page.evaluate((selector, value) => {
                const input = document.querySelector(selector)
                if (input) {
                    input.value = value
                    input.dispatchEvent(new Event('input', { bubbles: true }))
                }
            }, newPasswordSelector, WALLET_PASSWORD)

            await page.evaluate((selector, value) => {
                const input = document.querySelector(selector)
                if (input) {
                    input.value = value
                    input.dispatchEvent(new Event('input', { bubbles: true }))
                }
            }, confirmPasswordSelector, WALLET_PASSWORD)

            console.log(`[Browser ${walletAddress.substring(0, 12)}] Pasted passwords.`)

            await page.evaluate(() => {
                const buttons = Array.from(document.querySelectorAll('button'))
                const btn = buttons.find(b => b.textContent.trim() === 'Import Wallet')
                if (btn) {
                    btn.scrollIntoView({ behavior: 'smooth', block: 'center' })
                    btn.click()
                    btn.dispatchEvent(new MouseEvent('click', { bubbles: true }))
                }
            })

            console.log(`[Browser ${walletAddress.substring(0, 12)}] Clicked "Import Wallet". Monitoring network for balance...`)



        } catch (importError) {
            console.error(`❌ [Browser ${walletAddress.substring(0, 12)}] Error during wallet import steps: ${importError.message}`)
            throw importError // Re-throw error
        }
        // --- End Wallet Import Steps ---

        // --- Wait Loop ---
        console.log(`[Browser ${walletAddress.substring(0, 12)}] Entering wait loop (Max: ${FAUCET_WAIT_TIMEOUT / 1000}s)...`)
        while (networkListenerActive && !balanceDetectedAndSaved && (Date.now() - startTime < FAUCET_WAIT_TIMEOUT)) { if (!page || page.isClosed()) { console.log(`[Browser ${walletAddress.substring(0, 12)}] Page closed prematurely during wait loop.`); networkListenerActive = false; break } await sleep(2000) }
        if (!balanceDetectedAndSaved && networkListenerActive) console.log(`[Browser ${walletAddress.substring(0, 12)}] Timed out waiting for balance.`); else if (!balanceDetectedAndSaved && !networkListenerActive) console.log(`[Browser ${walletAddress.substring(0, 12)}] Page closed before balance detected or timeout.`); else if (balanceDetectedAndSaved) console.log(`[Browser ${walletAddress.substring(0, 12)}] Exited wait loop (balance saved).`)
        // --- End Wait Loop ---

    } catch (error) { // Catch errors from connect, page creation, navigation, import steps
        console.error(`❌ [Browser ${walletAddress.substring(0, 12)}] Error in Puppeteer phase: ${error.message}`)
        // Avoid logging stack trace for expected selector errors
        if (!error.message.includes('Waiting for selector') && !error.message.includes("'More Options' button not found")) {
            console.error(error.stack)
        }
        balanceDetectedAndSaved = false // Ensure false on error
    } finally {
        networkListenerActive = false
        console.log(`[Browser ${walletAddress.substring(0, 12)}] Entering finally block.`)
        if (browser) { console.log(`[Browser ${walletAddress.substring(0, 12)}] Closing browser in finally block.`); await browser.close().catch(e => console.warn(`[Browser ${walletAddress.substring(0, 12)}] Error closing browser (finally): ${e.message}`)) }
        else { console.log(`[Browser ${walletAddress.substring(0, 12)}] Browser already closed or null in finally block.`) }
        browser = null; page = null // Nullify references
    }
    console.log(`[Browser ${walletAddress.substring(0, 12)}] detectBalanceAndSave returning: ${balanceDetectedAndSaved}`)
    return balanceDetectedAndSaved
}


// --- Worker Process (No Fallback Saves) ---
async function runWorker(workerId) {
    console.log(`[Worker ${workerId}] Starting...`); let walletInfo = null; let success = false
    try {
        console.log(`[Worker ${workerId}] Step 1: Generating Wallet...`); walletInfo = await generateWallet(); if (!walletInfo) { console.error(`[Worker ${workerId}] Failed to generate wallet. Aborting.`); return }
        console.log(`[Worker ${workerId}] Step 2: Getting Captcha Token...`); const captchaToken = await getRecaptchaToken(); if (!captchaToken) { console.error(`[Worker ${workerId}] Failed to get Captcha token. Aborting.`); return }
        console.log(`[Worker ${workerId}] Step 3: Requesting Faucet...`); const faucetAmountRaw = await requestFaucet(walletInfo.account, captchaToken); if (faucetAmountRaw === null) { console.log(`[Worker ${workerId}] Faucet request failed. Aborting.`); return }

        console.log(`[Worker ${workerId}] Step 4: Starting Browser Check...`); const detectedAndSaved = await detectBalanceAndSave(walletInfo)
        if (detectedAndSaved) { console.log(`✅ [Worker ${workerId}] SUCCESS: Wallet saved.`); success = true } else { console.log(`[Worker ${workerId}] Wallet balance NOT detected/saved.`) }
    } catch (error) { console.error(`❌ [Worker ${workerId}] UNEXPECTED ERROR: ${error.message}`); if (error.stack && !error.message.includes('Waiting for selector')) { console.error(error.stack) } if (walletInfo) console.error(` -> Wallet: ${walletInfo.account}`) }
    finally { const outcome = success ? "successfully" : "WITHOUT saving"; const walletMsg = walletInfo ? `for ${walletInfo.account.substring(0, 12)} ` : ""; console.log(`[Worker ${workerId}] Finished run ${walletMsg}${outcome}.`) }
}

// --- Worker Manager ---
async function workerManager() {
    console.log(`🚀 Starting Worker Manager (Max Concurrent: ${MAX_CONCURRENT_WORKERS})`); let activeWorkers = 0; let workerCounter = 0
    if (!fsSync.existsSync(localJsPath)) { console.error(`❌ [Manager] CRITICAL: Local JS file '${LOCAL_JS_FILENAME}' not found. Exiting.`); process.exit(1) } else { console.log(`[Manager] Local JS file '${LOCAL_JS_FILENAME}' found.`) }
    while (true) { if (activeWorkers < MAX_CONCURRENT_WORKERS) { workerCounter++; activeWorkers++; const currentWorkerId = workerCounter; console.log(`[Manager] Starting Worker ${currentWorkerId} (Active: ${activeWorkers}/${MAX_CONCURRENT_WORKERS})...`); runWorker(currentWorkerId).catch((error) => { console.error(`[Manager] Critical error from Worker ${currentWorkerId} promise: ${error.message}`); if (error.stack && !error.message.includes('Waiting for selector')) { console.error(error.stack) } }).finally(() => { activeWorkers--; console.log(`[Manager] Worker ${currentWorkerId} finished. (Active: ${activeWorkers}/${MAX_CONCURRENT_WORKERS})`) }); await sleep(5000) } else { await sleep(10000) } }
}

// --- Start the Process ---
workerManager().catch(error => { console.error("❌ FATAL ERROR in Worker Manager:", error.message); if (error.stack && !error.message.includes('Waiting for selector')) { console.error(error.stack) }; process.exit(1) })