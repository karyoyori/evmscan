// recaptcha.js
import fetch from 'node-fetch' // Or rely on global fetch in Node 18+
import * as cheerio from 'cheerio'
import { URL, URLSearchParams } from 'url'
import https from 'https'
// import HttpsProxyAgent from 'https-proxy-agent'; // Uncomment if using proxy

// --- Disable InsecureRequestWarning equivalent (by using a custom agent) ---
// WARNING: Disabling SSL verification is insecure!
const insecureAgent = new https.Agent({
    rejectUnauthorized: false
})

class Functions {
    /**
     * Extracts query parameters from a given URL and returns them as an object.
     * @param {string} url - The URL from which to extract the parameters.
     * @returns {object} - An object with query parameters and their values.
     */
    static _url_ext(url) {
        try {
            const parsedUrl = new URL(url)
            const params = new URLSearchParams(parsedUrl.search)
            const paramsDict = {}
            for (const [key, value] of params.entries()) {
                paramsDict[key] = value
            }
            return paramsDict
        } catch (e) {
            console.error("Error parsing URL:", e)
            return {}
        }
    }
}

/** Async Handler for reCAPTCHA Token */
// ***** CHANGE THIS LINE *****
export default class AsyncV3 { // Use 'export default' here
    /**
     * Asynchronous class to handle interactions with Google's reCAPTCHA service.
     * (Constructor and methods remain the same as before)
     * @param {object} options - Configuration options.
     * @param {number} [options.ar] - Parameter 'ar' for the request.
     * @param {string} [options.k] - Parameter 'k' for the request (site key).
     * @param {string} [options.co] - Parameter 'co' for the request.
     * @param {string} [options.hl="en"] - Parameter 'hl' for the request.
     * @param {string} [options.v] - Parameter 'v' for the request (version).
     * @param {string} [options.size="invisible"] - Parameter 'size' for the request.
     * @param {string} [options.cb] - Parameter 'cb' for the request.
     * @param {string} [options.url] - URL to extract parameters from (overrides individual parameters).
     * @param {string} [options.proxy] - Proxy URL string (e.g., "http://user:pass@host:port").
     * @param {string} [options.userAgent] - User-Agent header for the request.
     */
    constructor({
        ar, k, co, hl = "en", v, size = "invisible", cb, url, proxy,
        userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Avast/126.0.0.0'
    } = {}) {
        this.anchorUrlBase = "https://www.google.com/recaptcha/api2/anchor"
        const urlParams = url ? Functions._url_ext(url) : {}

        this.params = {
            ar: urlParams.ar ?? ar,
            k: urlParams.k ?? k,
            co: urlParams.co ?? co,
            hl: urlParams.hl ?? hl,
            v: urlParams.v ?? v,
            size: urlParams.size ?? size,
            cb: urlParams.cb ?? cb
        }

        this.anchorUrl = new URL(this.anchorUrlBase)
        Object.entries(this.params).forEach(([key, val]) => {
            if (val !== undefined && val !== null) {
                this.anchorUrl.searchParams.append(key, val)
            }
        })

        this.headers = {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "accept-encoding": "gzip, deflate, br, zstd",
            "accept-language": "en-US,en;q=0.6",
            "cache-control": "no-cache",
            "dnt": "1",
            "pragma": "no-cache",
            "priority": "u=0, i",
            "sec-ch-ua": '"Not)A;Brand";v="99", "Brave";v="127", "Chromium";v="127"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "none",
            "sec-fetch-user": "?1",
            "sec-gpc": "1",
            "upgrade-insecure-requests": "1",
            "user-agent": userAgent
        }

        this.agent = insecureAgent // Default to insecure agent (proxy logic omitted for brevity, add back if needed)
    }

    /**
     * Asynchronously retrieves the initial reCAPTCHA token from the HTML response.
     * @param {number} [maxRetries=3] - Maximum number of retry attempts.
     * @returns {Promise<string|null>} - The initial reCAPTCHA token or null if failed.
     */
    async _get_i_token(maxRetries = 3) {
        const url = this.anchorUrl.toString()
        // console.log(`Attempting GET: ${url}`); // Log the exact URL being fetched

        for (let attempt = 1;attempt <= maxRetries;attempt++) {
            try {
                const response = await fetch(url, {
                    method: 'GET',
                    headers: this.headers,
                    agent: this.agent
                })

                // console.log(`GET Attempt ${attempt}: Status ${response.status}`);
                if (response.ok) { // Status 200-299
                    const text = await response.text()
                    const $ = cheerio.load(text)
                    const tokenInput = $('#recaptcha-token')

                    if (tokenInput.length > 0 && tokenInput.attr('value')) {
                        // console.log(`GET Attempt ${attempt}: Found initial token.`);
                        return tokenInput.attr('value')
                    } else {
                        console.warn(`GET Attempt ${attempt}: recaptcha-token input not found or has no value.`)
                    }
                } else {
                    console.error(`GET Attempt ${attempt} failed: Status ${response.status}, ${response.statusText}`)
                }
            } catch (error) {
                console.error(`GET Attempt ${attempt} failed with error: ${error.message}`)
            }
        }
        console.error(`Failed to get initial token after ${maxRetries} attempts.`)
        return null
    }

    /**
     * Asynchronously retrieves the verification token using the initial token.
     * @param {string} initialToken - The initial token obtained from the HTML response.
     * @param {number} [maxRetries=3] - Maximum number of retry attempts.
     * @returns {Promise<string|null>} - The verification token response text or null if failed.
     */
    async _get_v_token(initialToken, maxRetries = 3) {
        const postUrlBase = "https://www.google.com/recaptcha/api2/reload"
        const postParams = new URLSearchParams({ k: this.params.k })
        const postData = new URLSearchParams({
            v: this.params.v,
            reason: "q",
            k: this.params.k,
            c: initialToken,
            co: this.params.co,
            hl: this.params.hl,
        })

        const postHeaders = {
            "accept": "*/*",
            "accept-encoding": "gzip, deflate, br, zstd",
            "accept-language": "en-US,en;q=0.7",
            "cache-control": "no-cache",
            "content-type": "application/x-www-form-urlencoded",
            "dnt": "1",
            "origin": "https://www.google.com",
            "pragma": "no-cache",
            "priority": "u=1, i",
            "referer": this.anchorUrl.toString(),
            "sec-ch-ua": this.headers["sec-ch-ua"],
            "sec-ch-ua-mobile": this.headers["sec-ch-ua-mobile"],
            "sec-ch-ua-platform": this.headers["sec-ch-ua-platform"],
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "sec-gpc": "1",
            "user-agent": this.headers['user-agent']
        }

        const fullPostUrl = `${postUrlBase}?${postParams.toString()}`
        // console.log(`Attempting POST: ${fullPostUrl}`);

        for (let attempt = 1;attempt <= maxRetries;attempt++) {
            try {
                const response = await fetch(fullPostUrl, {
                    method: 'POST',
                    headers: postHeaders,
                    body: postData.toString(),
                    agent: this.agent
                })

                // console.log(`POST Attempt ${attempt}: Status ${response.status}`);
                if (response.ok) {
                    const text = await response.text()
                    // console.log(`POST Attempt ${attempt}: Received verification response.`);
                    return text
                } else {
                    console.error(`POST Attempt ${attempt} failed (v_token): Status ${response.status}, ${response.statusText}`)
                }
            } catch (error) {
                console.error(`POST Attempt ${attempt} failed (v_token) with error: ${error.message}`)
            }
        }
        console.error(`Failed to get verification token after ${maxRetries} attempts.`)
        return null
    }

    /**
     * Orchestrates fetching the initial and verification tokens to get the final reCAPTCHA token.
     * @returns {Promise<string|null>} - The final reCAPTCHA token or null if any step failed.
     */
    async _get_token() {
        const initialToken = await this._get_i_token()
        if (initialToken) {
            const verificationResponse = await this._get_v_token(initialToken)
            if (verificationResponse) {
                try {
                    const match = verificationResponse.match(/"rresp","([^"]+)"/)
                    if (match && match[1]) {
                        // console.log("Successfully parsed final token.");
                        return match[1]
                    } else {
                        console.error("Could not parse final token from response. Response snippet:", verificationResponse.substring(0, 200))
                        return null
                    }
                } catch (e) {
                    console.error("Error parsing verification token response:", e)
                    console.error("Verification response snippet:", verificationResponse.substring(0, 200))
                    return null
                }
            } else {
                console.error("Failed to get verification response.")
                return null
            }
        } else {
            console.error("Failed to get initial token.")
            return null
        }
    }
}

