const Web3 = require('web3');
const wallets = require('../wallets.json');

async function autoSendAllWallets() {
  for (const wallet of wallets) {
    const web3 = new Web3(wallet.rpc);
    try {
      const account = web3.eth.accounts.privateKeyToAccount(wallet.privateKey);
      const balance = await web3.eth.getBalance(account.address);
      const gasPrice = await web3.eth.getGasPrice();

      if (parseFloat(web3.utils.fromWei(balance, 'ether')) > 0.0001) {
        const tx = {
          to: wallet.receiver,
          value: balance - gasPrice * 21000,
          gas: 21000,
          gasPrice
        };

        const signed = await account.signTransaction(tx);
        const sentTx = await web3.eth.sendSignedTransaction(signed.rawTransaction);
        console.log(`Sukses kirim dari ${account.address}:`, sentTx.transactionHash);
      }
    } catch (error) {
      console.error(`Gagal kirim dari ${wallet.privateKey}:`, error.message);
    }
  }
}

module.exports = { autoSendAllWallets };
