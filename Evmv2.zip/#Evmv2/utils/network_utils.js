function getChains() {
  return [
    {
      name: 'bsc',
      rpc: 'https://bsc-dataseed.binance.org/',
      tokens: [
        { symbol: 'BUSD', address: '0xe9e7cea3dedca5984780bafc599bd69add087d56' },
        { symbol: 'USDT', address: '0x55d398326f99059ff775485246999027b3197955' }
      ]
    },
    {
      name: 'eth',
      rpc: 'https://mainnet.infura.io/v3/YOUR_INFURA_KEY',
      tokens: [
        { symbol: 'USDT', address: '0xdac17f958d2ee523a2206206994597c13d831ec7' },
        { symbol: 'USDC', address: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48' }
      ]
    }
    // Tambahkan chain lain jika mau
  ];
}

module.exports = { getChains };
