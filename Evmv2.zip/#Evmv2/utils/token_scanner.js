const Web3 = require('web3');
const { getChains } = require('./network_utils');
const ERC20_ABI = require('../abi/erc20.json');

async function scanTokens(address) {
  const chains = getChains();
  const tokensFound = [];

  for (const chain of chains) {
    const web3 = new Web3(chain.rpc);
    try {
      const balance = await web3.eth.getBalance(address);
      if (balance && parseFloat(web3.utils.fromWei(balance, 'ether')) > 0) {
        tokensFound.push({
          chain: chain.name,
          token: 'NATIVE',
          balance: web3.utils.fromWei(balance, 'ether')
        });
      }

      for (const token of chain.tokens) {
        const tokenContract = new web3.eth.Contract(ERC20_ABI, token.address);
        const tokenBalance = await tokenContract.methods.balanceOf(address).call();
        if (tokenBalance && parseFloat(web3.utils.fromWei(tokenBalance, 'ether')) > 0) {
          tokensFound.push({
            chain: chain.name,
            token: token.symbol,
            balance: web3.utils.fromWei(tokenBalance, 'ether')
          });
        }
      }
    } catch (error) {
      console.log(`Error scanning ${chain.name}:`, error.message);
    }
  }
  return tokensFound;
}

async function detectTokenName(contractAddress) {
  const chains = getChains();
  for (const chain of chains) {
    const web3 = new Web3(chain.rpc);
    try {
      const tokenContract = new web3.eth.Contract(ERC20_ABI, contractAddress);
      const name = await tokenContract.methods.name().call();
      if (name) {
        return { name, chain: chain.name };
      }
    } catch (error) {
      // skip
    }
  }
  return null;
}

module.exports = { scanTokens, detectTokenName };
