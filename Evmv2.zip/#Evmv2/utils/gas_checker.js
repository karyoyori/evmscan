const axios = require('axios');

async function getEthGasPrice() {
  try {
    const res = await axios.get('https://ethgasstation.info/json/ethgasAPI.json');
    const gas = res.data;
    return {
      fast: gas.fast / 10,
      average: gas.average / 10,
      safeLow: gas.safeLow / 10
    };
  } catch (err) {
    console.error('Gagal mengambil gas price:', err.message);
    return null;
  }
}

module.exports = { getEthGasPrice };
