import requests

def check_token_risk(token_address):
    try:
        # Dexscreener: ambil data pair
        dex_url = f"https://api.dexscreener.com/latest/dex/pairs/solana/{token_address}"
        dex_res = requests.get(dex_url).json()

        if "pair" not in dex_res:
            return "Token tidak ditemukan di Dexscreener."

        pair_data = dex_res["pair"]
        price = pair_data.get("priceUsd", "N/A")
        liquidity = pair_data.get("liquidity", {}).get("usd", "N/A")
        fdv = pair_data.get("fdv", "N/A")
        volume = pair_data.get("volume", {}).get("h24", "N/A")
        txns = pair_data.get("txns", {}).get("h1", {}).get("buys", 0) + pair_data.get("txns", {}).get("h1", {}).get("sells", 0)

        # Cek likuiditas dan volume
        if float(liquidity) < 1000 or float(volume) < 500:
            status = "Potensi RUG: Likuiditas atau volume terlalu rendah."
        else:
            status = "Token terlihat AMAN berdasarkan data Dexscreener."

        # Ringkasan
        return (
            f"**Analisa Token**\n"
            f"Alamat: `{token_address}`\n"
            f"Harga: ${price}\n"
            f"Likuiditas: ${liquidity}\n"
            f"FDV: ${fdv}\n"
            f"Volume 24h: ${volume}\n"
            f"Transaksi/jam: {txns}\n"
            f"Status: {status}"
        )

    except Exception as e:
        return f"Gagal cek token: {str(e)}"
