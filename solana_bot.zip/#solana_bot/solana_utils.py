# Bagian import
import json, os, requests, base64
from solana.rpc.api import Client
from solana.keypair import Keypair
from solana.transaction import Transaction
from solana.rpc.commitment import Confirmed

# Konstanta
RPC_URL = "https://solana-mainnet.g.alchemy.com/v2/xdvDAqjd8LYRVF4a7FJ5vmpeJFfJBytC"
JUPITER_API = "https://quote-api.jup.ag/v6"
client = Client(RPC_URL)
TRADES_FILE = "trades.json"

# Fungsi wallet
def load_wallet():
    with open("wallet.json", "r") as f:
        data = json.load(f)
        return Keypair.from_secret_key(bytes(data["private_key"]))

def get_wallet_address():
    kp = load_wallet()
    return str(kp.public_key)

def get_sol_balance():
    kp = load_wallet()
    balance = client.get_balance(kp.public_key)
    return balance['result']['value'] / 1e9

# Fungsi Jupiter
def get_best_route(from_mint, to_mint, amount):
    params = {
        "inputMint": from_mint,
        "outputMint": to_mint,
        "amount": amount,
        "slippageBps": 100,
        "onlyDirectRoutes": False
    }
    res = requests.get(f"{JUPITER_API}/quote", params=params)
    return res.json().get("data", [])[0]

# Fungsi auto-buy
def auto_buy_token(token_address, amount_in_sol=0.1):
    try:
        wallet = load_wallet()
        wallet_pub = str(wallet.public_key)
        sol_mint = "So11111111111111111111111111111111111111112"

        route = get_best_route(sol_mint, token_address, int(amount_in_sol * 1e9))
        if not route:
            return "Gagal dapat rute swap."

        swap_res = requests.post(f"{JUPITER_API}/swap", json={
            "userPublicKey": wallet_pub,
            "route": route,
            "wrapUnwrapSOL": True,
            "asLegacyTransaction": True
        }).json()

        tx_b64 = swap_res.get("swapTransaction")
        tx_bytes = base64.b64decode(tx_b64)
        tx = Transaction.deserialize(tx_bytes)
        tx.sign(wallet)
        sig = client.send_transaction(tx, wallet, opts={"skip_preflight": True, "preflight_commitment": Confirmed})["result"]

        # Simpan harga beli token (untuk auto sell)
        token_price = get_token_price_dexscreener(token_address)
        amount_token = float(route['outAmount']) / 10**6
        save_buy_history(token_address, token_price, amount_token)

        return f"Sukses beli token!\nTX: https://solscan.io/tx/{sig}"

    except Exception as e:
        return f"Gagal auto buy: {str(e)}"

# Fungsi simpan dan load histori beli
def save_buy_history(token_address, buy_price, amount_token, target_profit=0.3):
    data = {"BUY_HISTORY": {}}
    if os.path.exists(TRADES_FILE):
        data = json.load(open(TRADES_FILE))
    data["BUY_HISTORY"][token_address] = {
        "buy_price": buy_price,
        "amount_token": amount_token,
        "target_profit": target_profit
    }
    with open(TRADES_FILE, "w") as f:
        json.dump(data, f, indent=2)

def load_trade_data(token_address):
    if not os.path.exists(TRADES_FILE):
        return None
    data = json.load(open(TRADES_FILE))
    return data["BUY_HISTORY"].get(token_address)

# Fungsi cek harga di Dexscreener
def get_token_price_dexscreener(token_address):
    url = f"https://api.dexscreener.com/latest/dex/pairs/solana/{token_address}"
    res = requests.get(url).json()
    if "pair" in res:
        return float(res["pair"].get("priceUsd", 0))
    return 0

# Fungsi auto sell
def auto_sell_token(token_address):
    try:
        trade = load_trade_data(token_address)
        if not trade:
            return "Token belum pernah dibeli."

        buy_price = trade["buy_price"]
        target_profit = trade["target_profit"]
        current_price = get_token_price_dexscreener(token_address)

        if current_price == 0:
            return "Gagal dapat harga sekarang."

        percent_gain = (current_price - buy_price) / buy_price
        if percent_gain < target_profit:
            return f"Profit belum tercapai: {percent_gain*100:.2f}%"

        # Proses jual
        wallet = load_wallet()
        sol_mint = "So11111111111111111111111111111111111111112"
        amount_token = int(trade["amount_token"] * 1e6)
        route = get_best_route(token_address, sol_mint, amount_token)
        if not route:
            return "Gagal cari rute jual."

        swap_res = requests.post(f"{JUPITER_API}/swap", json={
            "userPublicKey": str(wallet.public_key),
            "route": route,
            "wrapUnwrapSOL": True,
            "asLegacyTransaction": True
        }).json()

        tx_b64 = swap_res.get("swapTransaction")
        tx_bytes = base64.b64decode(tx_b64)
        tx = Transaction.deserialize(tx_bytes)
        tx.sign(wallet)
        sig = client.send_transaction(tx, wallet, opts={"skip_preflight": True, "preflight_commitment": Confirmed})["result"]

        return f"Token dijual dengan profit {percent_gain*100:.2f}%!\nTX: https://solscan.io/tx/{sig}"

    except Exception as e:
        return f"Gagal auto sell: {e}"
