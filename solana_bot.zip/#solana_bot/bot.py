from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, MessageHandler, ContextTypes, filters
from solana_utils import auto_buy_token, auto_sell_token, save_buy_history
import json

USER_STATE = {}
DEFAULT_PROFIT = 0.3
TARGET_PROFIT_FILE = "profit_config.json"

def save_profit_config(value):
    with open(TARGET_PROFIT_FILE, "w") as f:
        json.dump({"target_profit": value}, f)

def load_profit_config():
    if not os.path.exists(TARGET_PROFIT_FILE):
        return DEFAULT_PROFIT
    return json.load(open(TARGET_PROFIT_FILE)).get("target_profit", DEFAULT_PROFIT)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("Buy Token", callback_data="buy_token")],
        [InlineKeyboardButton("Auto Sell", callback_data="sell_token")],
        [InlineKeyboardButton("Set Target Profit", callback_data="set_profit")]
    ]
    await update.message.reply_text("Pilih tindakan:", reply_markup=InlineKeyboardMarkup(keyboard))

async def handle_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    action = query.data
    USER_STATE[query.from_user.id] = action

    if action == "set_profit":
        await query.message.reply_text("Kirim target profit dalam persen (contoh: 25)")
    else:
        await query.message.reply_text("Kirim contract address token:")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    state = USER_STATE.get(user_id)

    if not state:
        await update.message.reply_text("Gunakan /start untuk mulai.")
        return

    msg = update.message.text.strip()

    if state == "buy_token":
        profit = load_profit_config()
        response = auto_buy_token(msg)
        await update.message.reply_text(response)

    elif state == "sell_token":
        response = auto_sell_token(msg)
        await update.message.reply_text(response)

    elif state == "set_profit":
        try:
            value = float(msg) / 100
            save_profit_config(value)
            await update.message.reply_text(f"Target profit disimpan: {value*100:.2f}%")
        except:
            await update.message.reply_text("Format salah. Kirim angka saja, contoh: 30")

    USER_STATE[user_id] = None  # Reset state

# === MAIN ===
def main():
    BOT_TOKEN = "ISI_TOKEN_BOT_KAMU"
    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(handle_button))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("Bot jalan...")
    app.run_polling()
